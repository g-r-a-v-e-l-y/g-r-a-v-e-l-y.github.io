NOTICE:
This Help System is being developed by James Shelton/Shelton Software, Inc. and Bob Wells/Desert Winds Enterprise, without written or verbal consent of the LITESTEP DEVELOPMENT TEAM or any of its' associates. All information contained herein is sole property and expressed opinions of said developers.

GENERAL INFORMATION:
All window sizes and images are based on a 1024x768-resolution with 32bit true color.
I suggest making a folder under c:\litestep as "Help" (i.e. C:\Litestep\Help), then move all of the *.hlp files and this Readme1st.txt file into that folder.  Finally, move the lshelp.bmp into your C:\Litestep\images folder (or whichever folder you use as the default image folder).


Use one of the methods below to integrate the LS_HELP system into your Litestep shell:

*Shortcut "LS Help" -xx -xx lshelp.bmp .none .none c:\litestep\help\ls_help.hlp"

*Popup "LS Help" c:\litestep\help\ls_help.hlp

*Wharf "LS Help" lshelpbook.bmp folder
	*Wharf "OverView" lshelp.bmp c:\litestep\help\ls_help.hlp
	*Wharf "Step.rc" srchlp.bmp c:\litestep\help\ls_h1.hlp
	*Wharf "Modules.ini" modshlp.bmp c:\litestep\help\ls_h2.hlp
	*Wharf "Wharfs" wharfhlp.bmp c:\litestep\help\ls_h4.hlp
	*Wharf "Themes" thmhlp.bmp c:\litestep\help\ls_h7.hlp	
	*Wharf "Ext.Progs." exprgmhlp.bmp c:\litestep\help\ls_h8.hlp
	*Wharf "Internet" nethlp.bmp c:\litestep\help\ls_h13.hlp
	*Wharf "Disclaimer" abouthlp.bmp c:\litestep\help\ls_h14.hlp
*Wharf ~folder

*Hotkey Win H "c:\litestep\help\ls_help.hlp"


Alternatively, once you have moved all of the .hlp files to their own directory, you can simply double-click on the LS_HELP.HLP file and the main help window will come up. You can navigate anywhere within the Help System from this main window :)

We sincerely hope that this Help System can help to make Litestep an even more popular Windows Explorer shell replacement.  Enjoy!

James Shelton/Shelton Software, Inc.
Bob Wells/Desert Winds Enterprise
