#ifndef __WHARF_H
#define __WHARF_H

#include <vector>
#include "../litestep/wharfdata.h"

#define WHARF_UP                0
#define WHARF_DOWN              1
#define WHARF_LEFT              2
#define WHARF_RIGHT             3

// forward decl
class subwharfType;

typedef std::vector< subwharfType* > SubwharfVector;

class wharfType {
public:
	wharfType();

	virtual void Paint(HDC hdc, HDC src);
	virtual void PaintTitle(HDC hdc, HDC src);

  HINSTANCE hInst;
  HWND hWnd;
  HWND hsubwharfWnd;
  HBITMAP backImage;
  HBITMAP frontImage;
  char szName[256];
  char szCommand[MAX_PATH];
  char szParameters[256];
  int width;
  int height;
  int inWharfX;
  int inWharfY;
  int numSubwharfs;
  int subwharfX;
  int subwharfY;
  int subWharfWidth;
  int subWharfHeight;
  BOOL subwharfOpen;
  BOOL moving;
  BOOL closing;
  BOOL showbg;
  BOOL bPressed;
  BOOL bTogglePressed;
  int movingPos;
  int (FAR *initWharfModule)(HWND, HINSTANCE, wharfDataType*);
  int (FAR *quitWharfModule)(HINSTANCE);
  HRGN (FAR *GetLSRegion)(int, int);
  HRGN subRgn;
  //subwharfType *subwharfs;
	SubwharfVector subwharfs;
};

class subwharfType : public wharfType {
	wharfType *parent;

public:
	subwharfType(wharfType *p);

	virtual void Paint(HDC hdc, HDC src);

  HWND taskWnd;
};

typedef std::vector< wharfType* > WharfVector;

extern "C" {
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif

