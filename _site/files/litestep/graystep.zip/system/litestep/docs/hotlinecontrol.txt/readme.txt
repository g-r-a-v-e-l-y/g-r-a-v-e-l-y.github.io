                    *************************************
                    *           HotlineControl          *
                    *            by Visigoth            *
                    *       sgandhi@andrew.cmu.edu      *
                    *          ===============          *
                    *           Version: 1.0            *
                    *         February 6, 2001          *
                    *          ===============          *
                    * http://floach.pimpin.net/visigoth *
                    *************************************

Table of Contents
=================
i     Install
I.    About HotlineControl
II.   How to use HotlineControl


i. Install
==========
  To install HotlineControl, you can place it anywhere on your system.  You
  might want to add a shortcut to your Start Menu right next to Hotline.


I. About HotlineControl
=======================
  HotlineControl is meant for users of alternative shells under Windows, where
  Hotline acts in a very odd fashion, making itself unusable.  HotlineControl
  can help get around it, but it isn't perfect.  Definitely read the
  instructions below before using HotlineControl, otherwise you'll think it
  doesn't work at all.

II. How to use HotlineControl
=============================
  The trick to using Hotline under alternative shells is the advertisements
  that Hotline loads during the course of its use.  Users of alternative
  shells know that the main Hotline window shrinks in size and blocks the
  use of many toolbar buttons.  However, when Hotline loads an advertisement,
  the Hotline window becomes full sized.

  At this moment, you have a chance to click ONE button on the Hotline toolbar.
  HotlineControl does nothing for you in this area - you must interactively
  wait for either a server banner, or an advertisement to load and quickly
  select a toolbar button.

  Other unusable portions of Hotline are the positions of new windows.
  Meaning, when Hotline displays a message box, chat request, or other message
  box style windows, it displays them off-screen.  This is the only problem
  that HotlineControl `fixes.`  When Hotline displays a message off-screen,
  you should launch HotlineControl and click the "Center Hotline Windows"
  button.  This will bring message boxes, etc to the center of your screen,
  thereby letting you continue using Hotline.

  Hopefully I'll get some time to work on this some more in the future, but
  this is how it stands at the moment.

  