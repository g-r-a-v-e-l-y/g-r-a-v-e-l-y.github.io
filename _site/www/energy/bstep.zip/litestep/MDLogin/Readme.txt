-={ Models Login Dezign Beta.3 (Release 1 comes latest 10 of Janurai 1999) }=-
       -={ This program have only been tested on windows 9x }=-

-={ A windows NT version is soon to follow, BETA testers WANTED }=-
              -={ WRITE TO: BETA@FACES.ORG }=-
-={ Suggestions on how to make this program better is also WANTED }=-
           -={ Send to: BetterLogin@faces.org }=-


Please read the License.txt for information about mail addresses and stuff.



1. What Does it Do?

2. Installing.
2.1. Different Step.rc and Modules.ini

3. Changing Graphics/sounds.
    ( concerning only the skindir option )

4. Get it going FAST.
    ( You should really take a quick look on this. )

5. Extended Information
    ( Here you have all the information how to make mldlogin tweak/crash/loop/jump ;)



1. WHAT DOES IT DO?

Its a login dialog for windows machines. It will show you a Secure Login dialog.
( means that you cant escape it by ctrl+alt+del or so )
You also have options on which Shell to run at login 
(Useful if you are booting between Explorer and Litestep for example.)
It is fully customizable with skins and sounds through the setting.ini file. 



--

2. INSTALLING

Make sure you unzip it with the directory structure intact as it contains 
important subfolders.
When you have unzipped it you want to make it the shell of your system.
You have two ways to do this:

(1) Edit the settings.ini file, so it will run the correct program when 
    passing the login dialog.
    Then start the program ( it always puts itself as the shell when started )

(2) Open up the system.ini file in the directory windows and change the
    "shell=xxxx" line to "shell=PathToMldLogin\MldLogin.exe"
    and reboot.

If you have done any mistake and you cant continue from the login dialog box
when you have restarted, dont worry. Just start up in dos ( with F8 ) and change
the "shell=" to "shell=explorer.exe" to get it going again.


---


2.1. DIFFERENT STEP.RC AND MODULES.INI
  
I saw that someone wanted to have different step.rc and modules.ini depending
on which user that was logged on. So I added that function as well.
Here is a clip from the defaul settings.ini file:

    [User1]
    UserName=admin
    PassWord=admin
    LastProgram=c:\litestep\litestep.exe
    StepRc=c:\litestep\users\Crux\step.rc
    modulesIni=c:\litestep\users\Crux\modules.ini

Here you can see that user admin last ran litestep and that he
will use the Step.Rc and the modules.ini files located in 
"c:\litestep\users\Crux\". You can ofcourse just name one of them,
and you can delete both of the lines. Its up to you. 

 



--


3. CHANGING GRAPHICS/SOUNDS

In the mldlogin directory there are three directories called
"Standard1","Standard2" & "Standard3"

Those are skins/themes that come with the mldlogin program.
Standard1 are a single launcher theme ( you can not choose which
shell you want to start ). 
Standard2 and 3 are litestep/explorer prepared themes ( standard2 theme
is made by turran and is optimized for his Litestep theme.

To test the skins just write the correct directory on the line

"Skindir=" in the settings.ini file. So, if you want to test standard3 change to:
"Skindir=standard3"

Hard, eh. =).

-----
Okej. But how do you do your own "theme"?. EASY. ( I will soon release a config
editor that makes it even easier ( your 5 year old can do it then. =).

Go into the standard1 directory and open up the settings.ini file, there
you will see and understand. You can have animated gifs, waves, bmp's and stuff in 
there. Currently, only 2 gifs is supported. But that will be changed.

One thing though. The transparent color of the background is ff00ff and
if you make a new background to your theme or change an existing background
you have to remove the background.bmp.msk file that is made when starting
the program for the first time.

(When starting the program for the first time and the *.msk file is missing,
the program is generating a mask for the background ( it takes like 1-10 sec extra
depending on how big the background is, and how much transparecy it is ). 
So the next time you start, it will use that .msk file and it will not take
ANY extra time at all.

--





4. GET IT GOING FAST

As I know you wanna try this out as fast as possible, I will first give you 
a few pointers that you might wanna know ( otherwise the settings.ini file
is pretty informative ).

First open up the settings.ini, in there you might want to change or look at
the user settings, so you can enter litestep. =). 
Standard is:

USERNAME: admin
PASSWORD: admin

Next thing is the command to run litestep. If the litestep directory is wrong
you wont be able to start windows at all. So be sure to change;

Commandtorun1=c:\litestep\litestep.exe
CommandtoRun1Reboot=0
Commandtorun2=c:\LOS\LOS.exe
CommandtoRun2Reboot=0

to what you want. Standard login program is the commandtorun1=pathtoprogram.
The commandtoRun2Reboot will logoff the system (if set to 1 =).
This is a must when changing to explorer.
 
If you want to be able to switch between explorer and litestep, first change
the "skindir=standard1" to "skindir=3".
That makes the skin show you the explorer button, so you can choose it (good eh. =).




5. EXTENDED INFORMATION

Okej, Some *MIGHT WANNA KNOW* stuff first.
Background pic can be transparent, just make sure to have the
background color as 255,0,255 or $ff00ff. Check backgroundpic info further down.

*******IMPORTANT*********MUST READ*********
To use this with Litestep and similar programs, simply set MLDLogin to run LITESTEP.EXE
and/or EXPLORER.EXE as the shell in settings.ini ( commandtorun1 or 2 ).
(MLDlogin.exe will put itself as the shell when you run it. So if you are going to 
test it with like Command1torun=c:\windows\calc.exe, you will end up with having MLDlogin
as the shell, so be sure to set Command1Torun=c:\litestep\litestep.exe or whatever )
MLDLogin will disable the ALT+F4 and CTRL+ALT+DELETE keys ( SAFETY measure ), so you better
watch you steps. I suggest you make a backup copy of the settings.ini that comes with 
this program and then change the 

commandtorun1=c:\litestep\litestep.exe
to
commandtorun1=c:\windows\calc.exe

and if you want to test the second button

commandtorun2=c:\win98\explorer.exe
to
commandtorun2=c:\win98\sol.exe


REMEMBER THAT WHEN THE "COMMANDTORUNxREBOOT=1" is set, the program will
REBOOT THE COMPUTER FOR THAT COMMAND, HENCE MAKING THE MLDLOGIN PROGRAM RUN. WHICH WILL MAKE IT 
IMPOSSIBLE FOR YOU TO RUN WINDOWS (if you still have the calc.exe and sol.exe in the
settings. If you have explorer or litestep, it will be okej=)
If this happens, start up in command mode ( f8 in bootup )
and go into the windows directory, open up system.ini and delete the Shell= line and write

shell=explorer.exe

instead of the old line


*********************************************************
*REAL INFORMATIVE DEEP THOUGHTS ON THE PROGRAM BY TURRAN*
*********************************************************

The ini file is pretty self explainable. I suggest you check the ini file first and 
if there something you dont understand --> keep reading this . (You'll probably be discouraged 
to test it if you read on as its kinda messy below :)

Here goes.
First section is for usernames and passwords. It currently supports up to
10 accounts. Its also case-sensitive. Only a-z, A-Z and 0-9 (no �$@�@ now boy. =)
is applicable for username & password.
Also note that the X & Y coordinates are the X & Y of the bitmap youre using
as a background, not the screen resolution. It is possible to have a different 
size of the background bitmap than the one provided. 
The background is always in the center of the screen at startup. 
The X & Y are the top-left corner of the background bmp.

<n> = Means insert number here.
<t> = Means insert text here.
<p> = Means insert path here.
<nt> = Means insert text and/or number here.
(Heck, if youre gonna do a readme, you might just do it right :)

;///////////////////////////////////////////////////////////////////////////////
;Okej. First the settings for the SETTINGS.ini IN THE ROOT DIRECTORY OF MLDLOGIN
;///////////////////////////////////////////////////////////////////////////////


[User<n>]    			 Where <n> equals user number. 10 users supported.

UserName=<nt> 			 Where <nt> equals loginname.

PassWord=<nt> 		 	 Where <nt> equals password.

StepRc=<nt>			 Insert FULL path to the step.rc that you want
              			 the user to use.

ModulesIni=<nt>			 Insert FULL path to the modules.ini that you want
              			 the user to use.

[Settings] 		 	 A must. Dont remove or edit.

SkinDir=<p>		 	 Get settings for skin from this directory.
				 

CommandToRun1=<p>	 	 The command to run if the user selects the first 
				 button. You must provide a full path.

CommandtoRun1Reboot=<n>	         Possible choices are 0 or 1. Certain programs may
				 require a quick reboot (logout) for them to work (Like
			  	 the explorer shell). 0 means not to reboot and 1 
				 means to reboot.

CommandToRun2=<p>		 The command to run if the user selects the second 
				 button. You must provide a full path.

CommandtoRun2Reboot=<n>	         Possible choices are 0 or 1. Certain programs may
				 require a quick reboot (logout) for them to work (Like
			  	 the explorer shell). 0 means not to reboot and 1 
				 means to reboot.

GoThrough=<n>			 Internal command. Dont change this. (When the user selects
				 a program that is set to reboot, MLDLogin does not show itself
				 afterwards)









;///////////////////////////////////////////////////////////////////////////////
;Here is the settings for the SKIN DIRECTORY settings.ini file.
;///////////////////////////////////////////////////////////////////////////////


CommandToRun1Graphic=<p>	 The graphics for the first button when pressed. You have to
				 use the background for unpressed button graphic.

CommandToRun1X=<n>		 The X coordinate for the first (select program) button graphic.
CommandToRun1Y=<n>		 The Y coordinate for the first (select program) button graphic.

CommandToRun2Graphic=<p>	 The graphics for the second button when pressed. You have to
				 use the background for unpressed button graphic.

CommandToRun2X=<n>		 The X coordinate for the second (select program) button graphic.
CommandToRun2Y=<n>		 The Y coordinate for the second (select program) button graphic.

PromptX=<n>		 	 This is the Prompts X coordinates 
			         (where the text come out when the user writes it).
				 You may need to play around with this. Also accepts negative
				 coordinates like -20.
 
PromptY=<n>		 	 This is the Prompts Y coordinates
  			 	 (where the text come out when the user writes it).
				 You may need to play around with this. Also accepts negative
				 coordinates like -20.

PromptWidth=<n>			 The width of the prompt rectangle (should be as big as
				 the X size of the text panel to prevent users from typing
				 into the background).

PromptHeight=<n>		 The height of the prompt rectangle (should be as big as
				 the Y size of the text panel to prevent users from typing
				 into the background).

PromptFont=<t>			 The font to use when the uses types. Must be a installed
				 Windows font.

PromptFontColor=$<n>		 Promptfontcolor is the color of the font to use in the 
			  	 $RRGGBB manner ( standard RGB. )
				 MUST start with the $ sign and followed by 6 (six) digits.

PromptFontSize=<n>		 The font size.

BackgroundPic=<p>	 	 Background file to use. MLDLogin default to the 
			 	 folder for where the it is started, so just add
			 	 graphics\backround_to_use.bmp 
				 You may also specify a complete path to the file.
			         As in Litestep, the color 255,0,255 will be transparent.
				 A mask file (.MSK) will be created the first time you
				 start MLDLogin for that specific background you are using.
				 (This causes a small delay for first time starters =).
				 Simply remove that file if you are changing background.

NameRedButtonPic=<p>      	 First name light. If the user has not yet written a name
			         or types a incorrect one, this will show.

NameGreenButtonPic=<p>           Second name light. When the user types a name that
			         exists.

PassWordRedButtonPic=<p>         First password light. If the user has not yet written a 
			         password or types the incorrect one, this will show.

PasswordGreenButtonPic=<p>	 Second password light. When the user types the correct
				 password.

NameLampX=<n>		         The X coordinate for the 2 name lights (red/green).
NameLampy=<n>		         The Y coordinate for the 2 name lights (red/green).

PasswordLampX=<n>		 The X coordinate for the 2 password lights (red/green). 
PasswordLampY=<n>                The Y coordinate for the 2 password lights (red/green).

LoginSound=<p>			 The sound to play at startup.

NameCorrectSound=<p>		 Name accepted sound.
NameErrorSound=<p>		 Name NOT accepted sound.	

PasswordCorrectSound=<p>	 Password accepted sound.	
PasswordErrorSound=<p>		 Password NOT accepted sound.	

ControlALTDEL=<p>		 If the user tryes CTRL-ALT-DEL or ALT-F4 this sound will play.

TakeAwayTextSpeed=<n>		 The speed that the text disappears when the user 
				 press return.

Gif2Pic=<P>			 Path to gif file;
Gif2PicX=<n>			 x Coordinate of gif;
Gif2PicY=<n>			 y Coordinate of gif;
Gif2PicLoop=<1 or 0>		 Want it to loop, set it to 1, if you dont, set it to 0
Gif2PicAnimated=<1 or 0>	 Want it to animate, 1 for yes, 0 for no. =)
Gif2PicSpeed=<n>		 how Fast you want it to run? Standard is between
				 50 and 100; ( you can set any number, but dont crash
				 it please. =)


            