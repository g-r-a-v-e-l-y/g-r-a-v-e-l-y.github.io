LsTransparent by Carluchi verion 1.0.0.9 (Beta)

Fixed in this build -
**
Fixed problems with the 2.4.5 class of builds not doing anything

**
Fixed problem where nothing would happen if you only made 1 module Transparent


LsTransparent is a module that allows you to make most litestep modules transparent 
with some simple settings and !bang commands. You can control the level of transparency as well.
You can also fade in and out these modules with !bang commands.

I have included a screen shot of the module in action

This module is a BETA module, so expect bugs.

The module works in Win9x WinNT and Win2K. 

It does not make every module truely transparent like some other 
applications do in Win2k. It paints the modules to give the appearence
of them being transparent. Think of it as a poor man's real time 
Alpha Blending.

Any questions or comments are appreciated

Carl

carluchi@stratos.net

I usually hang out in #Ls_Help on Effnet (IRC) so stop by

